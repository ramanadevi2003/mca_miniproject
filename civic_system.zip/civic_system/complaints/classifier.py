import re

CATEGORY_KEYWORDS = {
    'road_damage':      ['road','pothole','crack','pavement','asphalt','broken road','damaged road','road hole','street crack','highway','tar','concrete break','footpath','pathway damage','road repair','bad road','bumpy road','road surface'],
    'garbage_overflow': ['garbage','trash','waste','litter','rubbish','dump','dustbin','bin overflow','overflowing','filth','dirty','stink','smell','refuse','debris','sanitation','unclean','pile of waste','plastic waste'],
    'water_leakage':    ['water leak','pipe burst','pipe break','water pipe','leakage','water overflow','flooding','water supply','tap','broken pipe','water wastage','water logging','puddle','water gushing','main pipe','plumbing','leak'],
    'streetlight':      ['streetlight','street light','lamp post','light not working','dark road','no light','bulb','lamp','electric pole','lighting','power failure','light out','broken light','faulty light','night dark','street lamp'],
    'drainage':         ['drain','drainage','sewer','blocked drain','clog','choked','overflow drain','manhole','sewage','stagnant water','waterlog','water stagnation','open drain','blocked sewer','gutter','storm drain','septic'],
}

CATEGORY_DISPLAY = {
    'road_damage':'Road Damage','garbage_overflow':'Garbage Overflow',
    'water_leakage':'Water Leakage','streetlight':'Streetlight Failure',
    'drainage':'Drainage Problem','other':'Other',
}

def _normalize(text):
    return re.sub(r'[^a-z0-9 ]', ' ', text.lower())

def classify_complaint(title, description, image_name=''):
    from complaints.models import AUTHORITY_MAP
    combined = _normalize(f"{title} {description}")
    words = combined.split()
    scores, hits = {}, {}
    for cat, keywords in CATEGORY_KEYWORDS.items():
        score = 0; h = []
        for kw in keywords:
            kn = _normalize(kw)
            if kn in combined:
                score += len(kn.split()) * 2; h.append(kw)
            else:
                for w in kn.split():
                    if w in words and len(w) > 3:
                        score += 1
                        if kw not in h: h.append(kw)
        scores[cat] = score; hits[cat] = h
    best = max(scores, key=scores.get)
    best_score = scores[best]
    total = sum(scores.values()) or 1
    if best_score == 0:
        return {'category':'other','confidence':0.5,'authority':AUTHORITY_MAP['other'],'reasoning':'No keywords detected.','display':'Other'}
    conf = round(min(0.55 + (best_score/total)*0.42, 0.97), 2)
    # image filename hint
    fn = (image_name or '').lower()
    for hint, cat in [('road','road_damage'),('pothole','road_damage'),('garbage','garbage_overflow'),('water','water_leakage'),('light','streetlight'),('drain','drainage')]:
        if hint in fn:
            if cat == best: conf = min(conf+0.05, 0.98)
            elif best == 'other': best = cat; conf = 0.60
    return {
        'category': best, 'confidence': conf,
        'authority': AUTHORITY_MAP.get(best, 'Municipal Corporation'),
        'reasoning': f"Keywords: {', '.join(hits[best][:5])}. Score: {best_score}/{total}.",
        'display': CATEGORY_DISPLAY.get(best, 'Other'),
    }
