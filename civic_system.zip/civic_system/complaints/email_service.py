"""
Email notification module for CivicAlert.
All email sending goes through this module.
Uses Django's email backend (console in dev, SMTP in prod).
"""
from django.core.mail import send_mail
from django.template.loader import render_to_string
from django.conf import settings
import logging

logger = logging.getLogger(__name__)


def send_complaint_submitted(complaint):
    """Email citizen confirming their complaint was received."""
    user = complaint.user
    if not user.email:
        return
    try:
        subject = f'[CivicAlert] Complaint #{complaint.id} Received — {complaint.title[:40]}'
        message = (
            f"Dear {user.get_full_name() or user.username},\n\n"
            f"Your complaint has been successfully submitted to CivicAlert.\n\n"
            f"📋 Complaint ID : #{complaint.id}\n"
            f"📌 Title        : {complaint.title}\n"
            f"🏷 Category     : {complaint.get_category_display()}\n"
            f"🏢 Routed To    : {complaint.authority}\n"
            f"📅 Submitted    : {complaint.created_at.strftime('%d %b %Y, %I:%M %p')}\n\n"
            f"You can track the status of your complaint by logging into CivicAlert.\n\n"
            f"Thank you for helping improve your community!\n\n"
            f"— CivicAlert Team"
        )
        send_mail(subject, message, settings.DEFAULT_FROM_EMAIL, [user.email], fail_silently=True)
    except Exception as e:
        logger.error(f"Email error (submitted): {e}")


def send_status_update(complaint, old_status, new_status, admin_notes=''):
    """Email citizen when their complaint status changes."""
    user = complaint.user
    if not user.email:
        return
    status_messages = {
        'assigned':    'Your complaint has been assigned to the relevant authority.',
        'in_progress': 'Work on your complaint has started. The team is actively addressing it.',
        'resolved':    'Great news! Your complaint has been resolved. Please rate your experience.',
        'rejected':    'Unfortunately your complaint has been rejected by the authority.',
    }
    try:
        subject = f'[CivicAlert] Complaint #{complaint.id} — Status Updated to {complaint.get_status_display()}'
        message = (
            f"Dear {user.get_full_name() or user.username},\n\n"
            f"{status_messages.get(new_status, 'Your complaint status has been updated.')}\n\n"
            f"📋 Complaint ID : #{complaint.id}\n"
            f"📌 Title        : {complaint.title}\n"
            f"🔄 Old Status   : {old_status.replace('_',' ').title()}\n"
            f"✅ New Status   : {complaint.get_status_display()}\n"
        )
        if admin_notes:
            message += f"\n📝 Authority Notes:\n{admin_notes}\n"
        if new_status == 'resolved':
            message += "\n⭐ Please log in to rate your experience and earn 5 bonus points!\n"
        message += "\nLog in to CivicAlert to view full details.\n\n— CivicAlert Team"
        send_mail(subject, message, settings.DEFAULT_FROM_EMAIL, [user.email], fail_silently=True)
    except Exception as e:
        logger.error(f"Email error (status update): {e}")


def send_badge_earned(user, badge_label, badge_icon, badge_description):
    """Email citizen when they earn a new badge."""
    if not user.email:
        return
    try:
        subject = f'[CivicAlert] You earned a new badge: {badge_label} {badge_icon}'
        message = (
            f"Dear {user.get_full_name() or user.username},\n\n"
            f"Congratulations! You've just earned a new badge on CivicAlert!\n\n"
            f"{badge_icon} {badge_label}\n"
            f"{badge_description}\n\n"
            f"Keep reporting civic issues to earn more badges and climb the leaderboard!\n\n"
            f"— CivicAlert Team"
        )
        send_mail(subject, message, settings.DEFAULT_FROM_EMAIL, [user.email], fail_silently=True)
    except Exception as e:
        logger.error(f"Email error (badge): {e}")


def send_sla_warning(complaint):
    """Email citizen when their complaint has been pending too long."""
    user = complaint.user
    if not user.email:
        return
    try:
        subject = f'[CivicAlert] Update on your complaint #{complaint.id}'
        message = (
            f"Dear {user.get_full_name() or user.username},\n\n"
            f"Your complaint has been pending for {complaint.age_days} days without resolution.\n\n"
            f"📋 Complaint ID : #{complaint.id}\n"
            f"📌 Title        : {complaint.title}\n"
            f"🏢 Authority    : {complaint.authority}\n"
            f"📅 Submitted    : {complaint.created_at.strftime('%d %b %Y')}\n\n"
            f"We've flagged this complaint for priority attention. "
            f"Our admin team has been alerted to follow up with the concerned authority.\n\n"
            f"— CivicAlert Team"
        )
        send_mail(subject, message, settings.DEFAULT_FROM_EMAIL, [user.email], fail_silently=True)
    except Exception as e:
        logger.error(f"Email error (SLA warning): {e}")


def send_complaint_reopened(complaint):
    """Email to notify that a rejected complaint was reopened."""
    user = complaint.user
    if not user.email:
        return
    try:
        subject = f'[CivicAlert] Complaint #{complaint.id} Reopened'
        message = (
            f"Dear {user.get_full_name() or user.username},\n\n"
            f"Your complaint has been successfully reopened and is back in the queue.\n\n"
            f"📋 Complaint ID : #{complaint.id}\n"
            f"📌 Title        : {complaint.title}\n"
            f"🔄 New Status   : Pending\n\n"
            f"Your complaint will be reviewed by the concerned authority again.\n\n"
            f"— CivicAlert Team"
        )
        send_mail(subject, message, settings.DEFAULT_FROM_EMAIL, [user.email], fail_silently=True)
    except Exception as e:
        logger.error(f"Email error (reopened): {e}")
