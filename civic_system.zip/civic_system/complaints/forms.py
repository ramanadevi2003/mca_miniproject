from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Complaint, UserProfile, Comment


class RegisterForm(UserCreationForm):
    email      = forms.EmailField(required=True)
    first_name = forms.CharField(max_length=50, required=True)
    last_name  = forms.CharField(max_length=50, required=True)
    phone      = forms.CharField(max_length=15, required=False)

    class Meta:
        model  = User
        fields = ('username', 'first_name', 'last_name', 'email', 'phone', 'password1', 'password2')

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email      = self.cleaned_data['email']
        user.first_name = self.cleaned_data['first_name']
        user.last_name  = self.cleaned_data['last_name']
        if commit:
            user.save()
            UserProfile.objects.get_or_create(
                user=user,
                defaults={'phone': self.cleaned_data.get('phone', '')}
            )
        return user


class ComplaintForm(forms.ModelForm):
    latitude  = forms.FloatField(required=False, widget=forms.HiddenInput())
    longitude = forms.FloatField(required=False, widget=forms.HiddenInput())

    class Meta:
        model  = Complaint
        fields = ['title', 'description', 'location_text', 'latitude', 'longitude']
        widgets = {
            'title':         forms.TextInput(attrs={'placeholder': 'Brief title of the issue', 'class': 'form-input'}),
            'description':   forms.Textarea(attrs={'placeholder': 'Describe the issue in detail...', 'rows': 4, 'class': 'form-input'}),
            'location_text': forms.TextInput(attrs={'placeholder': 'Area / Landmark / Address', 'class': 'form-input'}),
        }


class AdminComplaintUpdateForm(forms.ModelForm):
    class Meta:
        model  = Complaint
        fields = ['status', 'priority', 'admin_notes', 'category', 'authority']
        widgets = {
            'admin_notes': forms.Textarea(attrs={'rows': 3, 'class': 'form-input'}),
            'status':      forms.Select(attrs={'class': 'form-select'}),
            'priority':    forms.Select(attrs={'class': 'form-select'}),
            'category':    forms.Select(attrs={'class': 'form-select'}),
            'authority':   forms.TextInput(attrs={'class': 'form-input'}),
        }


class CommentForm(forms.ModelForm):
    class Meta:
        model   = Comment
        fields  = ['text']
        widgets = {'text': forms.Textarea(attrs={'placeholder': 'Add a comment or follow-up...', 'rows': 2, 'class': 'form-input'})}
        labels  = {'text': ''}


class ReopenForm(forms.Form):
    reason = forms.CharField(
        widget=forms.Textarea(attrs={'rows': 3, 'class': 'form-input', 'placeholder': 'Explain why this issue still needs attention...'}),
        label='Reason for reopening',
    )
