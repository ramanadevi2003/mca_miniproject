from django.db import models
from django.contrib.auth.models import User

CATEGORY_CHOICES = [
    ('road_damage',      'Road Damage'),
    ('garbage_overflow', 'Garbage Overflow'),
    ('water_leakage',    'Water Leakage'),
    ('streetlight',      'Streetlight Failure'),
    ('drainage',         'Drainage Problem'),
    ('other',            'Other'),
]

AUTHORITY_MAP = {
    'road_damage':      'Public Works Department',
    'garbage_overflow': 'Municipal Sanitation Department',
    'water_leakage':    'Water Authority',
    'streetlight':      'Electrical Department',
    'drainage':         'Drainage & Sewage Department',
    'other':            'Municipal Corporation',
}

STATUS_CHOICES = [
    ('pending',     'Pending'),
    ('assigned',    'Assigned'),
    ('in_progress', 'In Progress'),
    ('resolved',    'Resolved'),
    ('rejected',    'Rejected'),
]

PRIORITY_CHOICES = [
    ('low',    'Low'),
    ('medium', 'Medium'),
    ('high',   'High'),
    ('urgent', 'Urgent'),
]

POINT_RULES = {
    'submit_complaint':   10,
    'add_image':           5,
    'add_gps':             5,
    'complaint_assigned':  5,
    'complaint_resolved': 20,
    'first_complaint':    15,
    'rated_resolution':    5,
    'comment_added':       2,
    'reopen_complaint':    3,
}

BADGE_DEFS = [
    ('newcomer',    'Newcomer',       'Submitted first complaint',    '🌱',  0,    1,  0),
    ('reporter',    'Reporter',       '5 complaints submitted',       '📝',  0,    5,  0),
    ('contributor', 'Contributor',    '10 complaints submitted',      '📋',  0,   10,  0),
    ('photo_pro',   'Photo Pro',      '5 complaints with photos',     '📸',  0,    5,  0),
    ('resolver',    'Resolver',       'First complaint resolved',     '✅',  0,    0,  1),
    ('champion',    'Civic Champion', '5 complaints resolved',        '🏆',  0,    0,  5),
    ('hero',        'City Hero',      '10 complaints resolved',       '🦸',  0,    0, 10),
    ('centurion',   'Centurion',      'Earned 100 points',            '💯', 100,   0,  0),
    ('veteran',     'Veteran',        'Earned 500 points',            '⭐', 500,   0,  0),
    ('legend',      'Legend',         'Earned 1000 points',           '👑',1000,   0,  0),
]

LEVEL_THRESHOLDS = [
    (0,    'Newcomer',       '🌱'),
    (50,   'Reporter',       '📝'),
    (150,  'Contributor',    '📋'),
    (300,  'Advocate',       '🔔'),
    (500,  'Civic Champion', '🏆'),
    (750,  'City Guardian',  '🛡'),
    (1000, 'City Hero',      '🦸'),
    (1500, 'Legend',         '👑'),
]


def get_level(points):
    level_name, level_icon = 'Newcomer', '🌱'
    for threshold, name, icon in LEVEL_THRESHOLDS:
        if points >= threshold:
            level_name, level_icon = name, icon
    return level_name, level_icon


class UserProfile(models.Model):
    user    = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    phone   = models.CharField(max_length=15, blank=True)
    address = models.TextField(blank=True)
    points  = models.IntegerField(default=0)
    bio     = models.CharField(max_length=200, blank=True)
    theme   = models.CharField(max_length=10, default='dark', choices=[('dark','Dark'),('light','Light')])

    def __str__(self):
        return f"{self.user.username}'s Profile"

    @property
    def level_name(self):
        return get_level(self.points)[0]

    @property
    def level_icon(self):
        return get_level(self.points)[1]

    @property
    def next_level_points(self):
        for threshold, name, icon in LEVEL_THRESHOLDS:
            if self.points < threshold:
                return threshold
        return None


class Badge(models.Model):
    user        = models.ForeignKey(User, on_delete=models.CASCADE, related_name='user_badges')
    key         = models.CharField(max_length=30)
    label       = models.CharField(max_length=50)
    icon        = models.CharField(max_length=10)
    description = models.CharField(max_length=100)
    earned_at   = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'key')
        ordering = ['-earned_at']


class PointLog(models.Model):
    user       = models.ForeignKey(User, on_delete=models.CASCADE, related_name='point_logs')
    points     = models.IntegerField()
    reason     = models.CharField(max_length=100)
    complaint  = models.ForeignKey('Complaint', on_delete=models.SET_NULL, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']


class Notification(models.Model):
    NOTIF_TYPES = [
        ('status', 'Status Update'),
        ('points', 'Points Earned'),
        ('badge',  'Badge Earned'),
        ('system', 'System'),
        ('aging',  'SLA Alert'),
    ]
    user       = models.ForeignKey(User, on_delete=models.CASCADE, related_name='notifications')
    notif_type = models.CharField(max_length=20, choices=NOTIF_TYPES, default='system')
    title      = models.CharField(max_length=100)
    message    = models.TextField()
    complaint  = models.ForeignKey('Complaint', on_delete=models.SET_NULL, null=True, blank=True)
    is_read    = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']


class Complaint(models.Model):
    user          = models.ForeignKey(User, on_delete=models.CASCADE, related_name='complaints')
    title         = models.CharField(max_length=200)
    description   = models.TextField()
    location_text = models.CharField(max_length=300, blank=True)
    latitude      = models.FloatField(blank=True, null=True)
    longitude     = models.FloatField(blank=True, null=True)

    category   = models.CharField(max_length=50, choices=CATEGORY_CHOICES, default='other')
    authority  = models.CharField(max_length=100, blank=True)
    confidence = models.FloatField(default=0.0)

    status   = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    priority = models.CharField(max_length=10, choices=PRIORITY_CHOICES, default='medium')

    admin_notes  = models.TextField(blank=True)
    upvotes      = models.ManyToManyField(User, related_name='upvoted_complaints', blank=True)
    satisfaction = models.IntegerField(null=True, blank=True)

    # Reopen tracking
    reopen_count  = models.IntegerField(default=0)
    reopen_reason = models.TextField(blank=True)

    # SLA tracking
    sla_flagged   = models.BooleanField(default=False)

    created_at  = models.DateTimeField(auto_now_add=True)
    updated_at  = models.DateTimeField(auto_now=True)
    resolved_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"#{self.id} — {self.title}"

    def save(self, *args, **kwargs):
        if self.category and not self.authority:
            self.authority = AUTHORITY_MAP.get(self.category, 'Municipal Corporation')
        super().save(*args, **kwargs)

    @property
    def upvote_count(self):
        return self.upvotes.count()

    @property
    def comment_count(self):
        return self.comments.count()

    @property
    def age_days(self):
        from django.utils import timezone
        return (timezone.now() - self.created_at).days


class ComplaintImage(models.Model):
    """Supports multiple images per complaint."""
    complaint  = models.ForeignKey(Complaint, on_delete=models.CASCADE, related_name='images')
    image      = models.ImageField(upload_to='uploads/')
    caption    = models.CharField(max_length=100, blank=True)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['uploaded_at']


class Comment(models.Model):
    complaint  = models.ForeignKey(Complaint, on_delete=models.CASCADE, related_name='comments')
    user       = models.ForeignKey(User, on_delete=models.CASCADE)
    text       = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['created_at']


class StatusUpdate(models.Model):
    complaint  = models.ForeignKey(Complaint, on_delete=models.CASCADE, related_name='updates')
    updated_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    old_status = models.CharField(max_length=20)
    new_status = models.CharField(max_length=20)
    message    = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
