from .models import UserProfile, Badge, PointLog, Notification, BADGE_DEFS, POINT_RULES


def award_points(user, action, complaint=None, custom_reason=None):
    pts = POINT_RULES.get(action, 0)
    if pts == 0:
        return 0, []
    profile, _ = UserProfile.objects.get_or_create(user=user)
    profile.points += pts
    profile.save(update_fields=['points'])
    reason = custom_reason or action.replace('_', ' ').title()
    PointLog.objects.create(user=user, points=pts, reason=reason, complaint=complaint)
    Notification.objects.create(
        user=user, notif_type='points',
        title=f'+{pts} Points Earned!',
        message=f'You earned {pts} points for: {reason}.',
        complaint=complaint,
    )
    new_badges = check_and_award_badges(user, profile)
    return pts, new_badges


def check_and_award_badges(user, profile=None):
    if profile is None:
        profile, _ = UserProfile.objects.get_or_create(user=user)
    from .models import Complaint
    total      = Complaint.objects.filter(user=user).count()
    resolved   = Complaint.objects.filter(user=user, status='resolved').count()
    with_photo = Complaint.objects.filter(user=user, images__isnull=False).distinct().count()
    existing   = set(Badge.objects.filter(user=user).values_list('key', flat=True))
    new_badges = []
    for key, label, description, icon, pts_req, comp_req, res_req in BADGE_DEFS:
        if key in existing: continue
        ok = True
        if pts_req  and profile.points < pts_req: ok = False
        if comp_req and total    < comp_req:      ok = False
        if res_req  and resolved < res_req:       ok = False
        if key == 'photo_pro' and with_photo < 5: ok = False
        if ok:
            Badge.objects.create(user=user, key=key, label=label, icon=icon, description=description)
            Notification.objects.create(
                user=user, notif_type='badge',
                title=f'Badge Unlocked: {label} {icon}',
                message=f'You earned the "{label}" badge! {description}',
            )
            new_badges.append({'label': label, 'icon': icon})
    return new_badges


def get_leaderboard(limit=20):
    return UserProfile.objects.select_related('user').order_by('-points')[:limit]
