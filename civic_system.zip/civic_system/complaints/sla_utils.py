"""
SLA (Service Level Agreement) checker and analytics utilities.
Run check_sla_violations() periodically (e.g. via a management command or cron).
"""
from django.utils import timezone
from django.conf import settings
from datetime import timedelta


def check_sla_violations():
    """
    Flag complaints that have been pending/assigned/in_progress too long.
    Creates notifications and sends email warnings.
    Returns count of newly flagged complaints.
    """
    from .models import Complaint, Notification
    from .email_service import send_sla_warning

    warning_cutoff  = timezone.now() - timedelta(days=getattr(settings, 'SLA_WARNING_DAYS',  7))
    critical_cutoff = timezone.now() - timedelta(days=getattr(settings, 'SLA_CRITICAL_DAYS', 14))

    open_statuses = ['pending', 'assigned', 'in_progress']
    aging = Complaint.objects.filter(
        status__in=open_statuses,
        created_at__lte=warning_cutoff,
        sla_flagged=False,
    )

    flagged = 0
    for c in aging:
        c.sla_flagged = True
        c.save(update_fields=['sla_flagged'])

        level = 'critical' if c.created_at <= critical_cutoff else 'warning'
        Notification.objects.create(
            user       = c.user,
            notif_type = 'aging',
            title      = f'⏰ No update on complaint #{c.id} for {c.age_days} days',
            message    = (
                f'Your complaint "{c.title}" has been {c.get_status_display()} '
                f'for {c.age_days} days. We have flagged it for priority attention.'
            ),
            complaint  = c,
        )
        send_sla_warning(c)
        flagged += 1

    return flagged


def get_authority_analytics():
    """Return per-authority performance stats for admin dashboard."""
    from .models import Complaint
    from django.db.models import Count, Avg, F, ExpressionWrapper, DurationField

    authorities = (
        Complaint.objects
        .values('authority')
        .annotate(
            total=Count('id'),
            resolved=Count('id', filter=__import__('django.db.models', fromlist=['Q']).Q(status='resolved')),
            pending=Count('id',  filter=__import__('django.db.models', fromlist=['Q']).Q(status='pending')),
        )
        .order_by('-total')
    )
    return authorities


def get_resolution_time_stats():
    """Average days to resolve complaints."""
    from .models import Complaint
    resolved = Complaint.objects.filter(status='resolved', resolved_at__isnull=False)
    if not resolved.exists():
        return None
    total_days = sum(
        (c.resolved_at - c.created_at).days
        for c in resolved
    )
    return round(total_days / resolved.count(), 1)


def export_complaints_csv(queryset):
    """Return a CSV string for the given complaints queryset."""
    import csv
    import io
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        'ID', 'Title', 'Description', 'Category', 'Authority',
        'Status', 'Priority', 'Location', 'Latitude', 'Longitude',
        'Reported By', 'Email', 'AI Confidence (%)',
        'Upvotes', 'Comments', 'Satisfaction',
        'Submitted Date', 'Resolved Date', 'Age (days)',
        'Admin Notes',
    ])
    for c in queryset.select_related('user'):
        writer.writerow([
            c.id, c.title, c.description,
            c.get_category_display(), c.authority,
            c.get_status_display(), c.get_priority_display(),
            c.location_text, c.latitude or '', c.longitude or '',
            c.user.get_full_name() or c.user.username,
            c.user.email,
            round(c.confidence * 100, 1),
            c.upvote_count, c.comment_count,
            c.satisfaction or '',
            c.created_at.strftime('%d/%m/%Y %H:%M'),
            c.resolved_at.strftime('%d/%m/%Y %H:%M') if c.resolved_at else '',
            c.age_days,
            c.admin_notes,
        ])
    return output.getvalue()
