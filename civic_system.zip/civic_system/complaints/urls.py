from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    # Auth
    path('',           views.login_view,    name='home'),
    path('login/',     views.login_view,    name='login'),
    path('logout/',    views.logout_view,   name='logout'),
    path('register/',  views.register_view, name='register'),

    # Password reset (Django built-in views + custom templates)
    path('password-reset/',
         auth_views.PasswordResetView.as_view(
             template_name='registration/password_reset.html',
             email_template_name='email/password_reset_email.txt',
             subject_template_name='email/password_reset_subject.txt',
             success_url='/password-reset/done/',
         ), name='password_reset'),
    path('password-reset/done/',
         auth_views.PasswordResetDoneView.as_view(
             template_name='registration/password_reset_done.html',
         ), name='password_reset_done'),
    path('password-reset/confirm/<uidb64>/<token>/',
         auth_views.PasswordResetConfirmView.as_view(
             template_name='registration/password_reset_confirm.html',
             success_url='/password-reset/complete/',
         ), name='password_reset_confirm'),
    path('password-reset/complete/',
         auth_views.PasswordResetCompleteView.as_view(
             template_name='registration/password_reset_complete.html',
         ), name='password_reset_complete'),

    # Citizen portal
    path('dashboard/',           views.dashboard,          name='dashboard'),
    path('submit/',              views.submit_complaint,   name='submit_complaint'),
    path('complaints/',          views.complaint_list,     name='complaint_list'),
    path('complaints/<int:pk>/', views.complaint_detail,   name='complaint_detail'),
    path('profile/',             views.profile_view,       name='profile'),
    path('leaderboard/',         views.leaderboard_view,   name='leaderboard'),
    path('notifications/',       views.notifications_view, name='notifications'),
    path('feed/',                views.public_feed_view,   name='public_feed'),
    path('city-stats/',          views.city_stats_view,    name='city_stats'),
    path('map/',                 views.nearby_map_view,    name='nearby_map'),

    # Admin
    path('admin/dashboard/',           views.admin_dashboard,        name='admin_dashboard'),
    path('admin/complaints/',          views.admin_complaint_list,   name='admin_complaint_list'),
    path('admin/complaints/<int:pk>/', views.admin_complaint_detail, name='admin_complaint_detail'),
    path('admin/export/',              views.admin_export_csv,       name='admin_export_csv'),
    path('admin/run-sla/',             views.admin_run_sla_check,    name='admin_run_sla'),
    path('admin/analytics/',           views.admin_analytics_view,   name='admin_analytics'),

    # API
    path('api/complaint/<int:pk>/status/', views.api_complaint_status, name='api_complaint_status'),
    path('api/classify/',                  views.api_classify_preview, name='api_classify'),
    path('api/unread/',                    views.api_unread_count,     name='api_unread_count'),
    path('api/duplicate-check/',           views.api_duplicate_check,  name='api_duplicate_check'),
]
