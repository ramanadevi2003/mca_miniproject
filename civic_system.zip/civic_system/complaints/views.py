import json
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.forms import AuthenticationForm
from django.contrib import messages
from django.http import JsonResponse, HttpResponse
from django.utils import timezone
from django.db.models import Count, Avg, Q
from datetime import timedelta

from .models import (
    Complaint, ComplaintImage, StatusUpdate, UserProfile, Badge,
    PointLog, Notification, Comment, AUTHORITY_MAP, LEVEL_THRESHOLDS,
    CATEGORY_CHOICES, STATUS_CHOICES,
)
from .forms import RegisterForm, ComplaintForm, AdminComplaintUpdateForm, CommentForm, ReopenForm
from .classifier import classify_complaint
from .points_engine import award_points, check_and_award_badges, get_leaderboard
from .email_service import (
    send_complaint_submitted, send_status_update,
    send_badge_earned, send_complaint_reopened,
)
from .sla_utils import check_sla_violations, get_authority_analytics, get_resolution_time_stats, export_complaints_csv


def is_admin(user):
    return user.is_staff or user.is_superuser


# ── Auth ──────────────────────────────────────────────────────────────────────

def register_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, f'Welcome, {user.first_name}! Your account is ready.')
            return redirect('dashboard')
    else:
        form = RegisterForm()
    return render(request, 'registration/register.html', {'form': form})


def login_view(request):
    if request.user.is_authenticated:
        return redirect('admin_dashboard' if request.user.is_staff else 'dashboard')
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('admin_dashboard' if user.is_staff else 'dashboard')
        messages.error(request, 'Invalid username or password.')
    else:
        form = AuthenticationForm()
    return render(request, 'registration/login.html', {'form': form})


def logout_view(request):
    logout(request)
    return redirect('login')


# ── User views ────────────────────────────────────────────────────────────────

@login_required
def dashboard(request):
    complaints   = Complaint.objects.filter(user=request.user)
    profile, _   = UserProfile.objects.get_or_create(user=request.user)
    unread       = request.user.notifications.filter(is_read=False).count()
    aging_count  = complaints.filter(
        status__in=['pending','assigned','in_progress'],
        created_at__lte=timezone.now()-timedelta(days=7)
    ).count()
    stats = {
        'total':       complaints.count(),
        'pending':     complaints.filter(status='pending').count(),
        'in_progress': complaints.filter(status='in_progress').count(),
        'resolved':    complaints.filter(status='resolved').count(),
    }
    next_pts = profile.next_level_points
    prev_pts = 0
    for t, n, i in LEVEL_THRESHOLDS:
        if t <= profile.points: prev_pts = t
    progress_pct = 100
    if next_pts and next_pts != prev_pts:
        progress_pct = int(((profile.points - prev_pts) / (next_pts - prev_pts)) * 100)

    return render(request, 'complaints/dashboard.html', {
        'stats': stats, 'recent': complaints[:5],
        'profile': profile, 'progress_pct': progress_pct,
        'next_pts': next_pts, 'unread_notifs': unread,
        'aging_count': aging_count,
        'recent_badges': Badge.objects.filter(user=request.user).order_by('-earned_at')[:3],
        'recent_logs':   request.user.point_logs.all()[:5],
    })


@login_required
def submit_complaint(request):
    if request.method == 'POST':
        form = ComplaintForm(request.POST)
        if form.is_valid():
            complaint      = form.save(commit=False)
            complaint.user = request.user

            # Handle multiple images
            images = request.FILES.getlist('images')

            # Classify using first image name if available
            img_name = images[0].name if images else ''
            result   = classify_complaint(complaint.title, complaint.description, img_name)
            complaint.category   = result['category']
            complaint.authority  = result['authority']
            complaint.confidence = result['confidence']
            complaint.save()

            # Save all uploaded images
            for img in images:
                ComplaintImage.objects.create(complaint=complaint, image=img)

            StatusUpdate.objects.create(
                complaint=complaint, updated_by=request.user,
                old_status='', new_status='pending',
                message=(
                    f"Submitted. Auto-classified as '{result['display']}' "
                    f"({round(result['confidence']*100)}% confidence) → routed to {result['authority']}."
                )
            )

            # Points
            is_first = request.user.complaints.count() == 1
            pts, new_badges = award_points(request.user, 'submit_complaint', complaint)
            if images:
                award_points(request.user, 'add_image', complaint)
            if complaint.latitude:
                award_points(request.user, 'add_gps', complaint)
            if is_first:
                award_points(request.user, 'first_complaint', complaint)

            # Email
            send_complaint_submitted(complaint)

            # Badge emails
            for b in new_badges:
                send_badge_earned(request.user, b['label'], b['icon'], '')

            msg = f'Complaint #{complaint.id} submitted! Classified as "{result["display"]}" → {result["authority"]}. +{pts} pts!'
            if new_badges:
                msg += f' 🎖 New badge: {new_badges[0]["icon"]} {new_badges[0]["label"]}!'
            messages.success(request, msg)
            return redirect('complaint_detail', pk=complaint.pk)
    else:
        form = ComplaintForm()
    return render(request, 'complaints/submit.html', {'form': form})


@login_required
def complaint_list(request):
    complaints    = Complaint.objects.filter(user=request.user)
    status_filter = request.GET.get('status', '')
    if status_filter:
        complaints = complaints.filter(status=status_filter)
    return render(request, 'complaints/list.html', {'complaints': complaints, 'status_filter': status_filter})


@login_required
def complaint_detail(request, pk):
    complaint    = get_object_or_404(Complaint, pk=pk)
    updates      = complaint.updates.all()
    comments     = complaint.comments.select_related('user').all()
    images       = complaint.images.all()
    comment_form = CommentForm()
    reopen_form  = ReopenForm()

    if request.method == 'POST' and not request.user.is_staff:
        action = request.POST.get('action')

        if action == 'comment':
            comment_form = CommentForm(request.POST)
            if comment_form.is_valid():
                c = comment_form.save(commit=False)
                c.complaint = complaint; c.user = request.user; c.save()
                award_points(request.user, 'comment_added', complaint)
                messages.success(request, 'Comment added. +2 pts!')
                return redirect('complaint_detail', pk=pk)

        elif action == 'upvote':
            if request.user in complaint.upvotes.all():
                complaint.upvotes.remove(request.user)
            else:
                complaint.upvotes.add(request.user)
            return redirect('complaint_detail', pk=pk)

        elif action == 'rate' and complaint.status == 'resolved' and complaint.user == request.user:
            rating = int(request.POST.get('rating', 0))
            if 1 <= rating <= 5 and not complaint.satisfaction:
                complaint.satisfaction = rating
                complaint.save(update_fields=['satisfaction'])
                award_points(request.user, 'rated_resolution', complaint)
                messages.success(request, f'Thanks for rating! +5 pts')
                return redirect('complaint_detail', pk=pk)

        elif action == 'reopen' and complaint.status == 'rejected' and complaint.user == request.user:
            reopen_form = ReopenForm(request.POST)
            if reopen_form.is_valid():
                old_status = complaint.status
                complaint.status       = 'pending'
                complaint.reopen_count += 1
                complaint.reopen_reason = reopen_form.cleaned_data['reason']
                complaint.sla_flagged  = False
                complaint.save()
                StatusUpdate.objects.create(
                    complaint=complaint, updated_by=request.user,
                    old_status=old_status, new_status='pending',
                    message=f'Citizen reopened complaint. Reason: {reopen_form.cleaned_data["reason"]}',
                )
                award_points(request.user, 'reopen_complaint', complaint)
                send_complaint_reopened(complaint)
                messages.success(request, 'Complaint reopened and back in queue. +3 pts!')
                return redirect('complaint_detail', pk=pk)

    user_upvoted = request.user in complaint.upvotes.all()
    return render(request, 'complaints/detail.html', {
        'complaint': complaint, 'updates': updates,
        'comments': comments, 'images': images,
        'comment_form': comment_form, 'reopen_form': reopen_form,
        'user_upvoted': user_upvoted,
    })


@login_required
def profile_view(request):
    profile, _ = UserProfile.objects.get_or_create(user=request.user)
    badges     = Badge.objects.filter(user=request.user)
    point_logs = request.user.point_logs.all()[:20]
    complaints = Complaint.objects.filter(user=request.user)
    next_pts   = profile.next_level_points
    prev_pts   = 0
    for t, n, i in LEVEL_THRESHOLDS:
        if t <= profile.points: prev_pts = t
    progress_pct = 100
    if next_pts and next_pts != prev_pts:
        progress_pct = int(((profile.points - prev_pts) / (next_pts - prev_pts)) * 100)

    if request.method == 'POST':
        action = request.POST.get('action')
        if action == 'update_profile':
            profile.bio   = request.POST.get('bio', '')[:200]
            profile.phone = request.POST.get('phone', '')[:15]
            profile.save()
            messages.success(request, 'Profile updated.')
        elif action == 'toggle_theme':
            profile.theme = 'light' if profile.theme == 'dark' else 'dark'
            profile.save(update_fields=['theme'])
        return redirect('profile')

    stats = {
        'total': complaints.count(),
        'resolved': complaints.filter(status='resolved').count(),
        'pending': complaints.filter(status='pending').count(),
        'with_image': complaints.filter(images__isnull=False).distinct().count(),
    }
    return render(request, 'complaints/profile.html', {
        'profile': profile, 'badges': badges,
        'point_logs': point_logs, 'stats': stats,
        'progress_pct': progress_pct, 'next_pts': next_pts,
    })


@login_required
def leaderboard_view(request):
    top_users  = get_leaderboard(20)
    profile, _ = UserProfile.objects.get_or_create(user=request.user)
    user_rank  = None
    for i, p in enumerate(UserProfile.objects.order_by('-points'), 1):
        if p.user == request.user:
            user_rank = i; break
    return render(request, 'complaints/leaderboard.html', {
        'top_users': top_users, 'user_rank': user_rank, 'profile': profile,
    })


@login_required
def notifications_view(request):
    notifs = request.user.notifications.all()
    notifs.filter(is_read=False).update(is_read=True)
    return render(request, 'complaints/notifications.html', {'notifications': notifs})


def city_stats_view(request):
    total    = Complaint.objects.count()
    resolved = Complaint.objects.filter(status='resolved').count()
    by_cat   = Complaint.objects.values('category').annotate(count=Count('id')).order_by('-count')
    avg_sat  = Complaint.objects.filter(satisfaction__isnull=False).aggregate(a=Avg('satisfaction'))['a']
    top_locs = (Complaint.objects.exclude(location_text='')
                .values('location_text').annotate(count=Count('id')).order_by('-count')[:5])
    avg_days = get_resolution_time_stats()
    return render(request, 'complaints/city_stats.html', {
        'total': total, 'resolved': resolved,
        'pending': Complaint.objects.filter(status='pending').count(),
        'in_prog': Complaint.objects.filter(status='in_progress').count(),
        'by_cat': by_cat,
        'avg_sat': round(avg_sat, 1) if avg_sat else None,
        'top_locs': top_locs,
        'avg_days': avg_days,
        'recent_resolved': Complaint.objects.filter(status='resolved').order_by('-resolved_at')[:5],
        'resolve_rate': int(resolved/total*100) if total else 0,
    })


def public_feed_view(request):
    complaints = Complaint.objects.select_related('user').all()
    category   = request.GET.get('category', '')
    status_f   = request.GET.get('status', '')
    if category: complaints = complaints.filter(category=category)
    if status_f: complaints = complaints.filter(status=status_f)
    return render(request, 'complaints/public_feed.html', {
        'complaints': complaints[:30], 'categories': CATEGORY_CHOICES,
        'statuses': STATUS_CHOICES, 'category': category, 'status_f': status_f,
    })


@login_required
def nearby_map_view(request):
    gps_complaints = (Complaint.objects
        .exclude(latitude=None).exclude(longitude=None)
        .select_related('user').order_by('-created_at')[:200])
    points = [{
        'id': c.id, 'title': c.title,
        'category': c.category, 'category_display': c.get_category_display(),
        'status': c.status, 'status_display': c.get_status_display(),
        'lat': c.latitude, 'lng': c.longitude,
        'location': c.location_text or '',
        'date': c.created_at.strftime('%d %b %Y'),
        'url': f'/complaints/{c.id}/',
        'upvotes': c.upvote_count,
    } for c in gps_complaints]
    stats = {
        'total': len(points),
        'pending': sum(1 for p in points if p['status'] == 'pending'),
        'resolved': sum(1 for p in points if p['status'] == 'resolved'),
    }
    return render(request, 'complaints/nearby_map.html', {
        'points_json': json.dumps(points),
        'stats': stats,
        'total_complaints': Complaint.objects.count(),
    })


# ── Admin views ───────────────────────────────────────────────────────────────

@login_required
@user_passes_test(is_admin)
def admin_dashboard(request):
    complaints = Complaint.objects.all()
    aging      = complaints.filter(
        status__in=['pending','assigned','in_progress'],
        created_at__lte=timezone.now()-timedelta(days=7)
    )
    avg_sat    = complaints.filter(satisfaction__isnull=False).aggregate(a=Avg('satisfaction'))['a']
    avg_days   = get_resolution_time_stats()
    authority_stats = list(get_authority_analytics())

    stats = {
        'total':       complaints.count(),
        'pending':     complaints.filter(status='pending').count(),
        'assigned':    complaints.filter(status='assigned').count(),
        'in_progress': complaints.filter(status='in_progress').count(),
        'resolved':    complaints.filter(status='resolved').count(),
        'rejected':    complaints.filter(status='rejected').count(),
        'aging':       aging.count(),
    }
    return render(request, 'admin_panel/dashboard.html', {
        'stats': stats,
        'by_category': complaints.values('category').annotate(count=Count('id')).order_by('-count'),
        'recent': complaints[:10],
        'aging_complaints': aging.order_by('created_at')[:5],
        'avg_sat':  round(avg_sat, 1) if avg_sat else 'N/A',
        'avg_days': avg_days or 'N/A',
        'top_users': get_leaderboard(5),
        'authority_stats': authority_stats,
    })


@login_required
@user_passes_test(is_admin)
def admin_complaint_list(request):
    complaints      = Complaint.objects.select_related('user').all()
    status_filter   = request.GET.get('status', '')
    category_filter = request.GET.get('category', '')
    search          = request.GET.get('search', '')
    aging_only      = request.GET.get('aging', '')

    if status_filter:   complaints = complaints.filter(status=status_filter)
    if category_filter: complaints = complaints.filter(category=category_filter)
    if search:
        complaints = complaints.filter(
            Q(title__icontains=search)|Q(user__username__icontains=search)|Q(location_text__icontains=search)
        )
    if aging_only:
        complaints = complaints.filter(
            status__in=['pending','assigned','in_progress'],
            created_at__lte=timezone.now()-timedelta(days=7)
        )
    return render(request, 'admin_panel/complaint_list.html', {
        'complaints': complaints, 'status_filter': status_filter,
        'category_filter': category_filter, 'search': search,
        'aging_only': aging_only,
        'categories': CATEGORY_CHOICES, 'statuses': STATUS_CHOICES,
    })


@login_required
@user_passes_test(is_admin)
def admin_complaint_detail(request, pk):
    complaint = get_object_or_404(Complaint, pk=pk)
    if request.method == 'POST':
        form = AdminComplaintUpdateForm(request.POST, instance=complaint)
        if form.is_valid():
            old_status = complaint.status
            updated    = form.save(commit=False)
            if updated.status == 'resolved' and not complaint.resolved_at:
                updated.resolved_at = timezone.now()
            updated.save()
            if old_status != updated.status:
                StatusUpdate.objects.create(
                    complaint=complaint, updated_by=request.user,
                    old_status=old_status, new_status=updated.status,
                    message=updated.admin_notes or f"Status updated to {updated.get_status_display()}."
                )
                Notification.objects.create(
                    user=complaint.user, notif_type='status',
                    title=f'Complaint #{pk} — {updated.get_status_display()}',
                    message=f'Your complaint "{complaint.title}" is now {updated.get_status_display()}.',
                    complaint=complaint,
                )
                # Email notification
                send_status_update(complaint, old_status, updated.status, updated.admin_notes)
                # Points
                if updated.status == 'assigned':
                    award_points(complaint.user, 'complaint_assigned', complaint)
                elif updated.status == 'resolved':
                    pts, new_badges = award_points(complaint.user, 'complaint_resolved', complaint)
                    for b in new_badges:
                        send_badge_earned(complaint.user, b['label'], b['icon'], '')
            messages.success(request, f'Complaint #{pk} updated.')
            return redirect('admin_complaint_detail', pk=pk)
    else:
        form = AdminComplaintUpdateForm(instance=complaint)
    return render(request, 'admin_panel/complaint_detail.html', {
        'complaint': complaint,
        'updates': complaint.updates.all(),
        'comments': complaint.comments.select_related('user').all(),
        'images': complaint.images.all(),
        'form': form,
    })


@login_required
@user_passes_test(is_admin)
def admin_export_csv(request):
    """Export filtered complaints to CSV."""
    complaints      = Complaint.objects.select_related('user').all()
    status_filter   = request.GET.get('status', '')
    category_filter = request.GET.get('category', '')
    if status_filter:   complaints = complaints.filter(status=status_filter)
    if category_filter: complaints = complaints.filter(category=category_filter)

    csv_data = export_complaints_csv(complaints)
    response = HttpResponse(csv_data, content_type='text/csv')
    filename = f'civicalert_export_{timezone.now().strftime("%Y%m%d_%H%M%S")}.csv'
    response['Content-Disposition'] = f'attachment; filename="{filename}"'
    return response


@login_required
@user_passes_test(is_admin)
def admin_run_sla_check(request):
    """Manually trigger SLA check from admin panel."""
    flagged = check_sla_violations()
    messages.success(request, f'SLA check complete. {flagged} complaint(s) newly flagged as aging.')
    return redirect('admin_dashboard')


@login_required
@user_passes_test(is_admin)
def admin_analytics_view(request):
    """Detailed analytics page for admins."""
    avg_days       = get_resolution_time_stats()
    authority_stats = list(get_authority_analytics())
    by_category    = list(Complaint.objects.values('category').annotate(count=Count('id')).order_by('-count'))
    monthly_data   = []
    for i in range(6, -1, -1):
        dt    = timezone.now() - timedelta(days=i*30)
        month = dt.strftime('%b %Y') if i > 0 else 'This month'
        start = dt.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        end   = (start + timedelta(days=32)).replace(day=1)
        monthly_data.append({
            'month':    dt.strftime('%b'),
            'total':    Complaint.objects.filter(created_at__gte=start, created_at__lt=end).count(),
            'resolved': Complaint.objects.filter(status='resolved', created_at__gte=start, created_at__lt=end).count(),
        })

    aging_counts = [
        ('7-14 days', Complaint.objects.filter(
            status__in=['pending','assigned','in_progress'],
            created_at__lte=timezone.now()-timedelta(days=7),
            created_at__gte=timezone.now()-timedelta(days=14),
        ).count()),
        ('14-30 days', Complaint.objects.filter(
            status__in=['pending','assigned','in_progress'],
            created_at__lte=timezone.now()-timedelta(days=14),
            created_at__gte=timezone.now()-timedelta(days=30),
        ).count()),
        ('30+ days', Complaint.objects.filter(
            status__in=['pending','assigned','in_progress'],
            created_at__lte=timezone.now()-timedelta(days=30),
        ).count()),
    ]

    return render(request, 'admin_panel/analytics.html', {
        'avg_days': avg_days or 0,
        'authority_stats': authority_stats,
        'by_category': by_category,
        'monthly_data': monthly_data,
        'monthly_json': json.dumps(monthly_data),
        'aging_counts': aging_counts,
        'avg_sat': Complaint.objects.filter(satisfaction__isnull=False).aggregate(a=Avg('satisfaction'))['a'] or 0,
        'total': Complaint.objects.count(),
        'resolved': Complaint.objects.filter(status='resolved').count(),
    })


# ── API ───────────────────────────────────────────────────────────────────────

@login_required
def api_complaint_status(request, pk):
    if not request.user.is_staff:
        complaint = get_object_or_404(Complaint, pk=pk, user=request.user)
    else:
        complaint = get_object_or_404(Complaint, pk=pk)
    return JsonResponse({'id': complaint.pk, 'status': complaint.status,
                         'status_display': complaint.get_status_display(),
                         'updated': complaint.updated_at.isoformat()})


@login_required
def api_classify_preview(request):
    if request.method == 'POST':
        return JsonResponse(classify_complaint(
            request.POST.get('title', ''),
            request.POST.get('description', '')
        ))
    return JsonResponse({'error': 'POST required'}, status=400)


@login_required
def api_unread_count(request):
    return JsonResponse({'count': request.user.notifications.filter(is_read=False).count()})


@login_required
def api_duplicate_check(request):
    if request.method != 'POST':
        return JsonResponse({'duplicates': []})
    import re
    title = request.POST.get('title', '').strip()
    if not title:
        return JsonResponse({'duplicates': []})
    stop  = {'the','and','for','are','was','has','have','this','that','with','there','road','street','area'}
    words = [w for w in re.sub(r'[^a-z0-9 ]',' ',title.lower()).split() if len(w)>3 and w not in stop]
    if not words:
        return JsonResponse({'duplicates': []})
    cutoff = timezone.now() - timedelta(days=30)
    q = Q()
    for w in words[:5]: q |= Q(title__icontains=w)
    recent = Complaint.objects.filter(q, created_at__gte=cutoff).exclude(status='rejected')[:5]
    dupes  = []
    for c in recent:
        c_words   = set(re.sub(r'[^a-z0-9 ]',' ',c.title.lower()).split())
        overlap   = len(set(words) & c_words)
        if overlap >= 1:
            dupes.append({'id':c.id,'title':c.title,'status':c.status,
                          'status_display':c.get_status_display(),
                          'category':c.get_category_display(),
                          'location':c.location_text or 'No location',
                          'date':c.created_at.strftime('%d %b %Y'),
                          'url':f'/complaints/{c.id}/','overlap':overlap})
    dupes.sort(key=lambda x: x['overlap'], reverse=True)
    return JsonResponse({'duplicates': dupes[:3]})
